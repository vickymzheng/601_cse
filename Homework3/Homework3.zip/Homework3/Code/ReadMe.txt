1. There are 3 different python program for this project, the names are hw3_dataSet1.py, hw3_dataset2.py, hw3_dataset3.py. The first program is for attweb_net, the second is for physics_collaboration_net and the third is for yeast_undurected_metabolic. All the program are written with python 2.7.

2. To run the code, just make sure the txt file of the dataset is in the same folder with the code.

3. You can change k and r in the code to get different clustering result.

4. The program use sklearn package to normalize the data.

5. The output of the code will be the cluster of each node, the sequence of the node is the same as the sequence of the nodes in the net file, which I believe is the sequence of the appearance of the node in the provided dataset file. It will also give the total number of the clusters.

6. if you uncomment the bottom part of the code, it will output each node name and the cluster it belongs to.

7. To get the flu file, I just simply copy the cluster sequence into the txt file and convert it to the cluster file and use Pajek to visualize it.



Thank you very much for grading.